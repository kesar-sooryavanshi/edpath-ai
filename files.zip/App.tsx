import { useState } from "react";
import Landing from "./components/Landing";
import Chat from "./components/Chat";

export type View = "landing" | "chat";

export default function App() {
  const [view, setView] = useState<View>("landing");
  const [firstMessage, setFirstMessage] = useState("");

  function handleStart(message: string) {
    setFirstMessage(message);
    setView("chat");
  }

  return (
    <div className="app-root">
      {view === "landing" ? (
        <Landing onStart={handleStart} />
      ) : (
        <Chat initialMessage={firstMessage} onBack={() => setView("landing")} />
      )}
    </div>
  );
}
