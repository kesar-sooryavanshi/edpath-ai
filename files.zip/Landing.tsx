import { useState, useEffect, useRef } from "react";

interface Props {
  onStart: (message: string) => void;
}

const SUGGESTIONS = [
  { icon: "⚡", text: "Explain JavaScript in simple words" },
  { icon: "🗺️", text: "Create a roadmap for web development" },
  { icon: "🤖", text: "Teach me AI from beginner to advanced" },
  { icon: "🎯", text: "How do I learn DSA effectively?" },
];

export default function Landing({ onStart }: Props) {
  const [input, setInput] = useState("");
  const [visible, setVisible] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Trigger fade-in after mount
    const t = setTimeout(() => setVisible(true), 50);
    inputRef.current?.focus();
    return () => clearTimeout(t);
  }, []);

  function handleSubmit() {
    if (input.trim()) onStart(input.trim());
  }

  function handleKey(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") handleSubmit();
  }

  return (
    <div className={`landing ${visible ? "landing--visible" : ""}`}>
      {/* Background orbs */}
      <div className="orb orb--blue" />
      <div className="orb orb--purple" />
      <div className="orb orb--cyan" />

      {/* Noise grain overlay */}
      <div className="grain" />

      {/* Logo */}
      <header className="landing__header">
        <div className="logo">
          <span className="logo__icon">✦</span>
          <span className="logo__text">EdPath AI</span>
        </div>
        <p className="logo__tagline">Your AI Learning Partner</p>
      </header>

      {/* Hero */}
      <main className="landing__main">
        <div className="hero">
          <h1 className="hero__heading">
            Ask Anything.<br />
            <span className="hero__heading--accent">Learn Everything.</span>
          </h1>
          <p className="hero__subheading">
            Your personal AI teacher for every skill
          </p>
        </div>

        {/* Input */}
        <div className="search-box">
          <div className="search-box__inner">
            <span className="search-box__icon">✦</span>
            <input
              ref={inputRef}
              className="search-box__input"
              type="text"
              placeholder="Ask anything..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKey}
            />
            <button
              className={`search-box__btn ${input.trim() ? "search-box__btn--active" : ""}`}
              onClick={handleSubmit}
              disabled={!input.trim()}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>
          <p className="search-box__hint">Press Enter to ask</p>
        </div>

        {/* Suggestions */}
        <div className="suggestions">
          {SUGGESTIONS.map((s, i) => (
            <button
              key={i}
              className="suggestion-card"
              style={{ animationDelay: `${0.4 + i * 0.08}s` }}
              onClick={() => onStart(s.text)}
            >
              <span className="suggestion-card__icon">{s.icon}</span>
              <span className="suggestion-card__text">{s.text}</span>
              <span className="suggestion-card__arrow">→</span>
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}
