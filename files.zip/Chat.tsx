import { useState, useEffect, useRef } from "react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface Props {
  initialMessage: string;
  onBack: () => void;
}

async function askAI(messages: Message[]): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system:
        "You are EdPath AI, a world-class educational assistant. Explain concepts clearly, use examples, and make learning enjoyable. Be concise but thorough.",
      messages,
    }),
  });

  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.content?.[0]?.text ?? "No response received.";
}

function TypingDots() {
  return (
    <div className="typing-dots">
      <span />
      <span />
      <span />
    </div>
  );
}

export default function Chat({ initialMessage, onBack }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Fade-in on mount, then send initial message
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 50);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (visible && initialMessage) {
      sendMessage(initialMessage);
    }
  }, [visible]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const userMsg: Message = { role: "user", content: trimmed };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput("");
    setLoading(true);

    try {
      const reply = await askAI(updated);
      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error";
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `⚠️ Error: ${msg}` },
      ]);
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  }

  function handleKey(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") sendMessage(input);
  }

  return (
    <div className={`chat ${visible ? "chat--visible" : ""}`}>
      {/* Background */}
      <div className="orb orb--blue orb--dim" />
      <div className="orb orb--purple orb--dim" />
      <div className="grain" />

      {/* Topbar */}
      <header className="chat__header">
        <button className="back-btn" onClick={onBack}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Back
        </button>
        <div className="logo logo--small">
          <span className="logo__icon">✦</span>
          <span className="logo__text">EdPath AI</span>
        </div>
        <div style={{ width: 80 }} />
      </header>

      {/* Messages */}
      <div className="chat__messages">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`message message--${msg.role}`}
            style={{ animationDelay: `${i * 0.04}s` }}
          >
            {msg.role === "assistant" && (
              <div className="message__avatar">✦</div>
            )}
            <div className="message__bubble">
              {msg.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="message message--assistant">
            <div className="message__avatar">✦</div>
            <div className="message__bubble message__bubble--typing">
              <TypingDots />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div className="chat__footer">
        <div className="chat-input">
          <input
            ref={inputRef}
            className="chat-input__field"
            type="text"
            placeholder="Ask a follow-up..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            disabled={loading}
          />
          <button
            className={`chat-input__btn ${input.trim() && !loading ? "chat-input__btn--active" : ""}`}
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="22" y1="2" x2="11" y2="13" />
              <polygon points="22 2 15 22 11 13 2 9 22 2" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
